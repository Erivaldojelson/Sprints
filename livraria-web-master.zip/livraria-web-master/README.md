# Bem vindo, 
Esse é um projeto para uma loja virtual de livraria. 
Você pode testar o funcionamento da pagina nesse [LINK](https://felipeaguiarn.github.io/livraria-web/)
### Desenvolvido 
Em HTML, CSS (FlexBox/Grid), Javascript, Bootstrap (Carosel)  

## Funcionalidades:
+++ em desenvolvimento
- [x] melhor responsividade
- [ ] shopping cart (simulação)
- [ ] descrição de item (Popover?)
- [ ] mais funcionalidades (Favoritos, ???)
- [ ] melhorar a integração dos itens via json. (por algum motivo o github não esta alterando)
___

![Image of WebPage-1](https://raw.githubusercontent.com/felipeaguiarn/sebo-leste/master/Screenshot-1.png)

![Image of WebPage-2](https://raw.githubusercontent.com/felipeaguiarn/sebo-leste/master/Screenshot-2.png)
