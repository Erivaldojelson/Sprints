# Lista a Fazer (To-Do List)

Lista de afazeres, é digitado um afazer no campo tarefa, a tarefa é criada e ao clicar na checkbox deixa o afazer feito ou desfeito.

Desenvolvido por Bruno Trindade e Leonardo Maia

![image](https://user-images.githubusercontent.com/92823045/143139386-7640e576-c6a2-4c4e-9c30-87a684c80d23.png)

